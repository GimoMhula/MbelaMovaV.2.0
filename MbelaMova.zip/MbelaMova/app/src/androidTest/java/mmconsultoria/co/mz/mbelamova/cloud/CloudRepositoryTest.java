package mmconsultoria.co.mz.mbelamova.cloud;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class CloudRepositoryTest {

    @Test
    public void setCloudRoot() {

    }

    @Test
    public void upload() {
    }

    @Test
    public void removeChildFromCloud() {
    }

    @Test
    public void attachListener() {
    }

    @Test
    public void setPath() {
    }

    @Test
    public void getLiveData() {
    }
}