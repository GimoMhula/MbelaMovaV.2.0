package mmconsultoria.co.mz.mbelamova;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;


/**
 * A simple {@link Fragment} subclass.
 */
public class auth_pessoa_fragment extends Fragment {

    CheckBox checkBox;
    Button submitbtn;


    public auth_pessoa_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_auth_pessoa, container, false);

        checkBox = view.findViewById(R.id.checkB);
        submitbtn = view.findViewById(R.id.btn_submeter_pessoa);

        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkBox.isChecked()==true){
                    getActivity().getSupportFragmentManager().beginTransaction().
                            replace(R.id.contentor, new cadastroMotoristaFragment()).
                            commit();

                }
                else {
                    startActivity(new Intent(getActivity(),MapsActivity.class));
                }
                    /*getActivity().
                            getSupportFragmentManager().
                            beginTransaction().
                            replace(R.id.contentor, new cadastroMotoristaFragment());}*/
            }
        });


        return view;
    }

}
