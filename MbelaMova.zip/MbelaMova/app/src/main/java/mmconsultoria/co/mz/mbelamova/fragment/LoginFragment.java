package mmconsultoria.co.mz.mbelamova.fragment;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import butterknife.BindView;
import butterknife.ButterKnife;
import mmconsultoria.co.mz.mbelamova.R;
import mmconsultoria.co.mz.mbelamova.model.BaseFragment;
import mmconsultoria.co.mz.mbelamova.view_model.Authentication;


/**
 * A simple {@link Fragment} subclass.
 */
public class LoginFragment extends BaseFragment {
    @BindView(R.id.login_fragment_phone_number_text)
    public EditText phoneNumber;
    @BindView(R.id.login_fragment_btn)
    public ImageButton loginBtn;

    private final static String MOZ_AREA_CODE = "+258";


    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_login, container, false);
        ButterKnife.bind(this, view);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        loginBtn.setOnClickListener(this::login);
    }

    public void login(View view) {
        Toast.makeText(getActivity(), "sdvdsvdvsdv", Toast.LENGTH_SHORT).show();
        if (validatePhoneNumberText()) {
            login(MOZ_AREA_CODE + phoneNumber.getText().toString().trim());
        }
    }

    private void login(String number) {
        Authentication authentication = ViewModelProviders.of(getActivity()).get(Authentication.class);
        authentication.signIn(getActivity(), number);

        swapFragment(R.id.login_container,new VerifySMSCodeFragment());
    }

    private boolean validatePhoneNumberText() {
        if (phoneNumber.getText().toString().trim().isEmpty()) {
            phoneNumber.setError(getActivity().getString(R.string.write_number));
            return false;
        }

        return true;
    }

}
