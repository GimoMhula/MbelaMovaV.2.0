package mmconsultoria.co.mz.mbelamova;

/**
 * Created by Nameless on 12/17/2018.
 */

public class Person {
    private String nome;
    private String id;
    private String phoneNumber;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
