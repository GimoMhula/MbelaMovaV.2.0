package mmconsultoria.co.mz.mbelamova.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProviders;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import mmconsultoria.co.mz.mbelamova.R;
import mmconsultoria.co.mz.mbelamova.model.BaseFragment;
import mmconsultoria.co.mz.mbelamova.view_model.Authentication;

public class VerifySMSCodeFragment extends BaseFragment {
    @BindView(R.id.sms_verification_code_text)
    public EditText verificationCodeText;
    private Authentication authentication;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_verify_sms_code,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        ButterKnife.bind(this,view);
    }

    @Override
    public void onStart() {
        super.onStart();

        authentication = ViewModelProviders.of(getActivity()).get(Authentication.class);
    }

    @OnClick(R.id.sms_verification_code_btn)
    public void verifyCode(View view){
        if (validateText()){
            final String code = verificationCodeText.getText().toString().trim();
            authentication.verifySmsCode(code,getActivity());
        }
    }

    private boolean validateText() {
        if (verificationCodeText.getText().toString().trim().isEmpty()){
            verificationCodeText.setError(getString(R.string.fill_text_message));
            return false;
        }
        return true;
    }

    @OnClick(R.id.sms_verification_resend_code_btn)
    public void resendCode(View view){
        authentication.resendCode(getActivity());
    }
}
