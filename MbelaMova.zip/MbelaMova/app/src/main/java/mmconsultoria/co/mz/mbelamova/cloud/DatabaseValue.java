package mmconsultoria.co.mz.mbelamova.cloud;

public enum DatabaseValue {
    VisitedPlacesTimeLine, Driver, People,
}
