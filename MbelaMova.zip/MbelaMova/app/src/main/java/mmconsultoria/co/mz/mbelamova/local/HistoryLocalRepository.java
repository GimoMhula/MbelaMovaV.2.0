package mmconsultoria.co.mz.mbelamova.local;

public class HistoryLocalRepository {

}
