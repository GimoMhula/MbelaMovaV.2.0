package mmconsultoria.co.mz.mbelamova.view_model;

import android.net.wifi.hotspot2.pps.Credential;
import android.util.Log;

import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModel;
import mmconsultoria.co.mz.mbelamova.cloud.CloudRepository;
import mmconsultoria.co.mz.mbelamova.model.Person;

public class Authentication extends ViewModel {
    public final String TAG = getClass().getSimpleName();

    private FirebaseAuth auth;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    private String verificationId;
    private PhoneAuthProvider.ForceResendingToken resendToken;
    private PhoneAuthCredential userCredential;

    private AuthListener listener;
    private String phoneNumber;

    public Authentication() {
        this.auth = FirebaseAuth.getInstance();
    }

    public boolean login() {
        return auth.getCurrentUser() != null;
    }

    public void signIn(final FragmentActivity activity, @NonNull String phoneNumber) {
        this.phoneNumber = phoneNumber;

        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {
                // This callback will be invoked in two situations:
                // 1 - Instant verification. In some cases the phone number can be instantly
                //     verified without needing to send or enter a verification code.
                // 2 - Auto-retrieval. On some devices Google Play services can automatically
                //     detect the incoming verification SMS and perform verification without
                //     user action.
                Log.d(TAG, "onVerificationCompleted:" + credential);

                signInWithPhoneAuthCredential(credential, activity, listener);
            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                // This callback is invoked in an invalid request for verification is made,
                // for instance if the the phone number format is not valid.
                Log.w(TAG, "onVerificationFailed", e);
                if (e instanceof FirebaseAuthInvalidCredentialsException) {
                    listener.onAction(null, null, AuthError.Invalid_Credentials);
                }

                if (e instanceof FirebaseTooManyRequestsException) {
                    listener.onAction(null, null, AuthError.To_Many_Login_Request);
                }

                if (e instanceof FirebaseNetworkException) {
                    listener.onAction(null, null, AuthError.Network);
                } else {
                    Log.d(TAG, "onVerificationFailed() called with: e = [" + e.getMessage() + "]");
                    listener.onAction(null, null, AuthError.Unknown);
                }

            }

            @Override
            public void onCodeSent(String verificationId, PhoneAuthProvider.ForceResendingToken token) {
                // The SMS verification code has been sent to the provided phone number, we
                // now need to ask the user to enter the code and then construct a credential
                // by combining the code with a verification ID.
                Log.d(TAG, "onCodeSent:" + verificationId);

                // Save verification ID and resending token so we can use them later
                Authentication.this.verificationId = verificationId;
                Authentication.this.resendToken = token;

            }
        };

        PhoneAuthProvider.getInstance(auth).verifyPhoneNumber(phoneNumber, 2, TimeUnit.MINUTES, activity, mCallbacks);

    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential, FragmentActivity activity, AuthListener listener) {
        auth.signInWithCredential(credential).addOnCompleteListener(activity, task -> {
            if (task.isSuccessful()) {


                FirebaseUser user = task.getResult().getUser();
                listener.onAction(user.getUid(), user.getPhoneNumber(), AuthError.None);

                Log.d(TAG, "onComplete() called with: task = [" + task + "]");


            } else {
                // Sign in failed, display a message and update the UI
                Log.w(TAG, "signInWithCredential:failure", task.getException());
                if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                    listener.onAction(null, null, AuthError.Invalid_Credentials);
                }

                if (task.getException() instanceof FirebaseTooManyRequestsException) {
                    listener.onAction(null, null, AuthError.To_Many_Login_Request);
                }

                if (task.getException() instanceof FirebaseNetworkException) {
                    listener.onAction(null, null, AuthError.Network);
                } else listener.onAction(null, null, AuthError.Unknown);


            }
        });

    }

    private void getUserFromCloud(@NonNull String id) {
        CloudRepository<Person> repository = new CloudRepository<>(Person.class);
        repository.attachListener((CloudRepository.OnSingleValueListener<Person>) (data, error, movement) -> {

        });

    }

    public void setListener(AuthListener listener) {
        this.listener = listener;
    }

    public void verifySmsCode(String code, FragmentActivity activity) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        signInWithPhoneAuthCredential(credential, activity, listener);
    }

    public void resendCode(FragmentActivity activity) {
        PhoneAuthProvider.getInstance(auth).verifyPhoneNumber(phoneNumber, 2, TimeUnit.MINUTES, activity, mCallbacks);
    }


    public interface AuthListener {
        void onAction(String id, String phoneNumber, AuthError error);
    }


    public enum AuthError {
        None, Network, Invalid_Credentials, Unknown, To_Many_Login_Request
    }
}
