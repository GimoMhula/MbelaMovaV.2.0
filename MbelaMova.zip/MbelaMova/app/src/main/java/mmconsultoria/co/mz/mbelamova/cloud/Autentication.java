package mmconsultoria.co.mz.mbelamova.cloud;

public class Autentication {
}
