package mmconsultoria.co.mz.mbelamova;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class FeedbackActivity extends AppCompatActivity {

    TextView texto;
    Typeface typeface;
    ImageButton enviar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        texto = (TextView)findViewById(R.id.feedbackMsg);
        enviar = findViewById(R.id.enviarOpiniao);

        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FeedbackActivity.this, Autenticacao.class));
                Toast.makeText(FeedbackActivity.this, "fhgdfgdhfhdgfgdhfgdhhfcdhggfhdhjgdjhgfjhdgfjhdgfhgdjhfgdjh", Toast.LENGTH_SHORT).show();
                //
                // loadFragment(c);

                /*startActivity(new Intent(FeedbackActivity.this, CadastroActivity.class));*/
            }
        });

        //Fonte externa
        typeface = Typeface.createFromAsset(getAssets(), "fonts/Gotham Light.otf");
        texto.setTypeface(typeface);


    }

    private void loadFragment(Fragment fragment) {
// create a FragmentManager
        FragmentManager fm = getFragmentManager();
// create a FragmentTransaction to begin the transaction and replace the Fragment
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
// replace the FrameLayout with new Fragment
        //fragmentTransaction.replace(R.id.conten, fragment);
        fragmentTransaction.commit(); // save the changes
    }
}
