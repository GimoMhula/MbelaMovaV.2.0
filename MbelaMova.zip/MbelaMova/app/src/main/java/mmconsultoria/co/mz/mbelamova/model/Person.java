package mmconsultoria.co.mz.mbelamova.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Arrays;

import mmconsultoria.co.mz.mbelamova.cloud.ImageHolder;

public class Person implements Parcelable, ImageHolder {
    public static final Creator<Person> CREATOR = new Creator<Person>() {
        @Override
        public Person createFromParcel(Parcel in) {
            return new Person(in);
        }

        @Override
        public Person[] newArray(int size) {
            return new Person[size];
        }
    };
    private String name;
    private String id;
    private String email;
    private String phoneNumber;
    private String photoUri;
    private String driverId;
    private Place[] places;


    public Person() {
    }

    protected Person(Parcel in) {
        places = in.createTypedArray(Place.CREATOR);
        name = in.readString();
        id = in.readString();
        email = in.readString();
        phoneNumber = in.readString();
        photoUri = in.readString();
        driverId = in.readString();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhotoUri() {
        return photoUri;
    }

    public void setPhotoUri(String photoUri) {
        this.photoUri = photoUri;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedArray(places, flags);
        dest.writeString(name);
        dest.writeString(id);
        dest.writeString(email);
        dest.writeString(phoneNumber);
        dest.writeString(photoUri);
        dest.writeString(driverId);
    }

    @Override
    public String toString() {
        return "People{" + "name='" + name + '\'' + ", id='" + id + '\'' + ", email='" + email + '\'' + ", phoneNumber='" + phoneNumber + '\'' + ", photoUri='" + photoUri + '\'' + ", driverId='" + driverId + '\'' + ", places=" + Arrays.toString(places) + '}';
    }
}
