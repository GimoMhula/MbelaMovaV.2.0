package mmconsultoria.co.mz.mbelamova.cloud;

public interface ImageHolder {
    String getPhotoUri();

    void setPhotoUri(String photoUri);
}
