package mmconsultoria.co.mz.mbelamova;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PromoActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promo);


   /*     disFButton.setButtonColor(getResources().getColor(R.color.colorAccent));
        disFButton.setShadowColor(getResources().getColor(R.color.colorPrimaryDark));
        disFButton.setShadowEnabled(true);
        disFButton.setShadowHeight(5);
        disFButton.setCornerRadius(5);*/
    }
}
