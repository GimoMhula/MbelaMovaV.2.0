package mmconsultoria.co.mz.mbelamova;

/**
 * Created by Nameless on 12/17/2018.
 */

public interface SimpleCallback<T> {
    void onSuccess(T data);
}
